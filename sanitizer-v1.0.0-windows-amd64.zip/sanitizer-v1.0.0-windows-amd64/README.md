# VeloCloud Diagnostic Sanitizer v1.0.0

- Version: 1.0.0
- Platform: windows / amd64
- Executable: `sanitizer.exe`

A single self-contained executable with the web UI embedded. It runs offline and needs no installed runtime, Node.js or database server.

## Command line

```
PowerShell: .\sanitizer.exe
sanitizer.exe version
sanitizer.exe inspect  BUNDLE
sanitizer.exe analyze  BUNDLE
sanitizer.exe sanitize -key-file KEYFILE BUNDLE
sanitizer.exe verify   OUTPUT
```

`inspect`, `analyze`, `sanitize` and `verify` accept `-json` and `-o FILE`. `sanitize` needs a hex key from `-key-file` or the `SANITIZER_KEY` environment variable. Run `sanitizer.exe` with no arguments for usage.

## Web UI

```
sanitizer.exe serve
```

Then open http://127.0.0.1:8080 (loopback only; change with `-addr`).

- On first run, a one-time setup token is printed to the terminal. Enter it in the browser to create the administrator account. Keep it out of logs and screenshots.
- Accounts are stored in `auth.db` and completed analyses in `history.db` (unencrypted), both in the data directory (`-data-dir`, default: your user config directory under `velocloud-diag-sanitizer`). Use `-history=false` to keep reports in memory only.
- Upload a diagnostic bundle as a ZIP. Limits: `-max-upload-mb`, `-max-expanded-mb`.

## Notes

- The tool never reports a bundle as "safe"; review its output before sharing a bundle.
- Analyzer reports contain no raw identifiers or paths. `inspect`, `sanitize` and `verify` reports can contain paths and should be treated as sensitive.
